// custom javascript

var formatAsPercentage = d3.format("%"),
	formatAsPercentage1Dec = d3.format(".1%"),
	formatAsInteger = d3.format(","),
	fsec = d3.time.format("%S s"),
	fmin = d3.time.format("%M m"),
	fhou = d3.time.format("%H h"),
	fwee = d3.time.format("%a"),
	fdat = d3.time.format("%d d"),
	fmon = d3.time.format("%b")
	;


//main function
$(function() {
	console.log('jquery is working!');
        var cnt=0;
	var NoComp=5;
        hideDivs();

        var headerContainer=document.getElementById("submit-button");
//      headerContainer.style.visibility = 'hidden';


        var filterVal="color"
        $.get( "/ajaxGetHiveUniqueItems/"+filterVal, function(data) {
        createDropdownList( "select-container1","selectName1",$.parseJSON(data));
        cnt=cnt+1;
        if(cnt>=NoComp){showDivs();}
        })

        filterVal="language"
        $.get( "/ajaxGetHiveUniqueItems/"+filterVal, function(data) {createDropdownList( "select-container3","selectName3",$.parseJSON(data));
        cnt=cnt+1;
        if(cnt>=NoComp){showDivs();}
        })

        filterVal="country"
        $.get( "/ajaxGetHiveUniqueItems/"+filterVal, function(data) {createDropdownList( "select-container4","selectName4",$.parseJSON(data));
        cnt=cnt+1;
        if(cnt>=NoComp){showDivs();}
        })

        filterVal="title_year"
        $.get( "/ajaxGetHiveUniqueItems/"+filterVal, function(data) {createDropdownList( "select-container2","selectName2",$.parseJSON(data));
        cnt=cnt+1;
        if(cnt>=NoComp){showDivs();}
        })
	
        filterlist='{"language": "(All)","country": "(All)","color": "(All)","title_year": "(All)"}'

        $.get( "/getMovieHiveList/"+filterlist, function(data) {createWordCloud($.parseJSON(data));
        cnt=cnt+1;
        if(cnt>=NoComp){showDivs();}
        })

});


//Convert Flask data into Json
function FlaskToJson(data) 
{	
	var jobj = JSON.parse(data);
	return jobj;
}

//Convert Flask data into Array
function KeywordsToArray(data) {
   var uniquelist = new Array(), i;
   uniquelist[0]="(All)"
   var jobj = JSON.parse(data);
	
    for(i = 0; i<jobj.length; i++) {
        uniquelist[i+1] = jobj[i].column;
    }
    return uniquelist;

}

//Filter complete data based on the passed sentiment
function filterSentimentData(Sentiment,data) {
	var ds = [];
	//window.alert(current_sent)
	current_sent=Sentiment
	//completeDataJson=detailedDataToJson;
	for (x in data) {
		 if(data[x].Sentiment==Sentiment){
		 	ds.push(data[x]);
		 } 
	}
	return ds;

}


function dropdownFilter1()
{
	if(current_sent=='All'){
		ds=detailedDataToJson;
	}
	else{
		ds=filterSentimentData(current_sent,detailedDataToJson)
		//window.alert(current_sent)
	}
		
	
	var item = document.getElementById("select-list");
	var selection = item.options[item.selectedIndex].value;
	var output = [];
	if (selection!="(All)")	{
		
		for (x in ds){
		 if(ds[x].Celebrities_Accessories==selection){
		 	output.push(ds[x]);
		 } 
		}
	
	}
	else{
		output=ds;
	}
	return output;
}

//function to be executed in 
function updateFromDropdown()
{
        try
        {
           var loadingimage=document.getElementById("wordCloudID");
           loadingimage.style.visibility = 'hidden';
           var loadingimage=document.getElementById("loadingimage");
           loadingimage.style.visibility = 'visible';
        }
        catch(err){console.log('Error in Hiding Objects ',err);}


        try{ var color=document.getElementById("selectName1").value; }catch(err){var color="(All)";}
        try{ var tittle_year=document.getElementById("selectName2").value; }catch(err){var tittle_year ="(All)";}
        try{ var language=document.getElementById("selectName3").value; }catch(err){var language="(All)";}
        try{ var country=document.getElementById("selectName4").value; }catch(err){var country="(All)";}

        var cnt=0;
        var NoComp=1;

        filters={"language":language,"country": country,"color": color,"title_year": tittle_year}
        filterlist=JSON.stringify(filters)
        
        console.log('Filter : ',filterlist)

        $.get( "/getMovieHiveList/"+filterlist, function(data) {createWordCloud($.parseJSON(data));
        cnt=cnt+1;
        if(cnt>=NoComp){showDivs();}
        })
}


function createDropdownList(divname,selectName,KeywordArray1) {
   var widthVar = Math.round(screen.width*.09);
   var heightVar = Math.round(screen.height*.030);
   //widthVar=100;heightVar=30;
   //alert(widthVar);
   var newDiv=document.createElement('div');
   var html = '<select style="width:'+widthVar+'px;  height:'+heightVar+'px;" class="select-list" id="'+selectName+'">', uniquewords = KeywordArray1, i;

   for(i = 0; i < uniquewords.length; i++) {
       html += "<option value='"+uniquewords[i].column+"'>"+uniquewords[i].column+"</option>";
   }
   html += '</select>';
   newDiv.innerHTML= html;
   document.getElementById(divname).appendChild(newDiv);
   
}





function createWordCloud(frequency_list)
{
    try{document.getElementById("wordCloudID").remove();}
    catch(err){console.log('Error in Deleting Graph Object: ',err);}

    var color = d3.scale.linear()
            .domain([0,1,2,3,4,5,6,10,15,20,100])
            .range(["#A183C3", "#fffff", "#f90014", "#00f9f9", "#00000", "#08a014", "#a05908", "#a00808", "#a09108", "#08a03a", "#a00891", "#00000"]);
    
    d3.layout.cloud().size([screen.width*.94, screen.height*.80])
            .words(frequency_list)
            .rotate(0)
	    //.fontSize(function(d) { return parseInt(d.size)+5; })
            .fontSize(function(d) { return 25; })
            .on("end", draw)
            .start();
	
    function draw(words) {
        drawWidth=(screen.width*.30).toString()
        drawHeight=(screen.height*.30).toString()
        translateString="translate(".concat(drawWidth).concat(",").concat(drawHeight).concat(")")
        //console.log(translateString)

        d3.select("#wordcloud").append("svg")
		.attr("id","wordCloudID")
                .attr("width", screen.width*.95)
                .attr("height", screen.height*.70)
                .attr("class", "#wordcloud")
                .append("g")
                // without the transform, words words would get cutoff to the left and top, they would
                // appear outside of the SVG area
                .attr("transform", translateString)
		//.attr("transform", "translate(700,300)")
                .selectAll("text")
                .data(words)
                .enter().append("text")
                //.style("font-size", function(d) { return parseInt(d.size) + "px"; })
                .style("font-size", function(d) { return 25 + "px"; })
                .style("fill", function(d, i) { return color(i); })
                .attr("transform", function(d) {
                    return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
                })
                .text(function(d) { return d.movie; })
		.append("svg:title") //mouseover title showing the figures
                .text(function(d) { return d.size +" : " + d.movie});
		;
    }
}




function hideDivs()
{
   var selectContainer1=document.getElementById("select-container1");
   selectContainer1.style.visibility = 'hidden';

   var selectContainer2=document.getElementById("select-container2");
   selectContainer2.style.visibility = 'hidden';

   var selectContainer3=document.getElementById("select-container3");
   selectContainer3.style.visibility = 'hidden';

   var selectContainer4=document.getElementById("select-container4");
   selectContainer4.style.visibility = 'hidden';

   var submitButton=document.getElementById("submit-button");
   submitButton.style.visibility = 'hidden';

   try
   {
      var wordCloudID=document.getElementById("wordCloudID");
      wordCloudID.style.visibility = 'hidden';
   }catch(err){console.log('Error in showing Objects ',err);}

   var loadingimage=document.getElementById("loadingimage");
   loadingimage.style.visibility = 'visible';
   //console.log(loadingimage)
}

function showDivs()
{
   var selectContainer1=document.getElementById("select-container1");
   selectContainer1.style.visibility = 'visible';

   var selectContainer2=document.getElementById("select-container2");
   selectContainer2.style.visibility = 'visible';

   var selectContainer3=document.getElementById("select-container3");
   selectContainer3.style.visibility = 'visible';

   var selectContainer4=document.getElementById("select-container4");
   selectContainer4.style.visibility = 'visible';

   var submitButton=document.getElementById("submit-button");
   submitButton.style.visibility = 'visible';
   
   try
   {
      var wordCloudID=document.getElementById("wordCloudID");
      wordCloudID.style.visibility = 'visible';
   }catch(err){console.log('Error in showing Objects ',err);}


   var loadingimage=document.getElementById("loadingimage");
   loadingimage.style.visibility = 'hidden';
}


